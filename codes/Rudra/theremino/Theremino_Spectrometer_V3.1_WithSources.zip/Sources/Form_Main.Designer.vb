﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Dim DesignerRectTracker11 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim CBlendItems11 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim CBlendItems12 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim DesignerRectTracker12 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim DesignerRectTracker1 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim CBlendItems1 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim CBlendItems2 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim DesignerRectTracker2 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim DesignerRectTracker3 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim CBlendItems3 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim CBlendItems4 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim DesignerRectTracker4 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim DesignerRectTracker5 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim CBlendItems5 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim CBlendItems6 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim DesignerRectTracker6 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim DesignerRectTracker7 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim CBlendItems7 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim CBlendItems8 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim DesignerRectTracker8 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim DesignerRectTracker9 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Dim CBlendItems9 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim CBlendItems10 As Theremino_Spectrometer.cBlendItems = New Theremino_Spectrometer.cBlendItems
        Dim DesignerRectTracker10 As Theremino_Spectrometer.DesignerRectTracker = New Theremino_Spectrometer.DesignerRectTracker
        Me.PBox_Camera = New System.Windows.Forms.PictureBox
        Me.Label_FramesPerSec = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_VideoInDevice = New System.Windows.Forms.GroupBox
        Me.Label_Millisec = New System.Windows.Forms.Label
        Me.Label_Resolution = New System.Windows.Forms.Label
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Menu_File = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_File_Exit = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_VideoinControls = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_TrimPoints = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_Trim1 = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_Trim2 = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_TrimSelect = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_Separator = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_SeparatorTab = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_SeparatorSemicolon = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Tools_SeparatorComma = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ENG = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ITA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_FRA = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_ESP = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_POR = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_DEU = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_JPN = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Language_CHI = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_ProgramHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_Technology = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_Construction = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_Help_Spectrums = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.Menu_Help_OpenProgramFolder = New System.Windows.Forms.ToolStripMenuItem
        Me.Menu_About = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.Tool_VideoControls = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveSpectrum = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveCamera = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveTotal = New System.Windows.Forms.ToolStripButton
        Me.Tools_Run = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.Tools_SaveDataFile = New System.Windows.Forms.ToolStripButton
        Me.Timer_1Hz = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox_Input = New System.Windows.Forms.GroupBox
        Me.Label_SizeY = New System.Windows.Forms.Label
        Me.Label_StartX = New System.Windows.Forms.Label
        Me.Label_StartY = New System.Windows.Forms.Label
        Me.Label_EndX = New System.Windows.Forms.Label
        Me.chk_Flip = New System.Windows.Forms.CheckBox
        Me.Label_RisingSpeed = New System.Windows.Forms.Label
        Me.Label_JpegQuality = New System.Windows.Forms.Label
        Me.Label_Path = New System.Windows.Forms.Label
        Me.Label_Name = New System.Windows.Forms.Label
        Me.LabelDot = New System.Windows.Forms.Label
        Me.GroupBox_SaveImage = New System.Windows.Forms.GroupBox
        Me.PBox_Spectrum = New System.Windows.Forms.PictureBox
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.Label_Filter = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label_FallingSpeed = New System.Windows.Forms.Label
        Me.Label_MaxPeak = New System.Windows.Forms.Label
        Me.Label_SlotWriteFile = New System.Windows.Forms.Label
        Me.Label_SlotRun = New System.Windows.Forms.Label
        Me.Label_SlotStop = New System.Windows.Forms.Label
        Me.GroupBox_SyncAndIntegration = New System.Windows.Forms.GroupBox
        Me.txt_FallingSpeed = New Theremino_Spectrometer.MyTextBox
        Me.txt_SlotStop = New Theremino_Spectrometer.MyTextBox
        Me.txt_SlotRun = New Theremino_Spectrometer.MyTextBox
        Me.txt_SlotWriteFile = New Theremino_Spectrometer.MyTextBox
        Me.btn_ResetSpectrumData = New Theremino_Spectrometer.MyButton
        Me.txt_RisingSpeed = New Theremino_Spectrometer.MyTextBox
        Me.txt_Filter = New Theremino_Spectrometer.MyTextBox
        Me.btn_Reference = New Theremino_Spectrometer.MyButton
        Me.btn_Dips = New Theremino_Spectrometer.MyButton
        Me.btn_Colors = New Theremino_Spectrometer.MyButton
        Me.btn_Peaks = New Theremino_Spectrometer.MyButton
        Me.btn_TrimScale = New Theremino_Spectrometer.MyButton
        Me.txt_JpegQuality = New Theremino_Spectrometer.MyTextBox
        Me.txt_FilePath = New Theremino_Spectrometer.MyTextBox
        Me.txt_FileName = New Theremino_Spectrometer.MyTextBox
        Me.ComboBox_FileType = New Theremino_Spectrometer.MyComboBox
        Me.txt_SizeY = New Theremino_Spectrometer.MyTextBox
        Me.txt_StartX = New Theremino_Spectrometer.MyTextBox
        Me.txt_EndX = New Theremino_Spectrometer.MyTextBox
        Me.txt_StartY = New Theremino_Spectrometer.MyTextBox
        Me.ComboBox_VideoInputDevice = New Theremino_Spectrometer.MyComboBox
        CType(Me.PBox_Camera, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_VideoInDevice.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox_Input.SuspendLayout()
        Me.GroupBox_SaveImage.SuspendLayout()
        CType(Me.PBox_Spectrum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox_SyncAndIntegration.SuspendLayout()
        Me.SuspendLayout()
        '
        'PBox_Camera
        '
        Me.PBox_Camera.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PBox_Camera.BackColor = System.Drawing.Color.DimGray
        Me.PBox_Camera.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PBox_Camera.ErrorImage = Nothing
        Me.PBox_Camera.InitialImage = Nothing
        Me.PBox_Camera.Location = New System.Drawing.Point(58, 14)
        Me.PBox_Camera.Name = "PBox_Camera"
        Me.PBox_Camera.Size = New System.Drawing.Size(272, 254)
        Me.PBox_Camera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PBox_Camera.TabIndex = 0
        Me.PBox_Camera.TabStop = False
        '
        'Label_FramesPerSec
        '
        Me.Label_FramesPerSec.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label_FramesPerSec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_FramesPerSec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FramesPerSec.Location = New System.Drawing.Point(85, 51)
        Me.Label_FramesPerSec.Name = "Label_FramesPerSec"
        Me.Label_FramesPerSec.Size = New System.Drawing.Size(44, 16)
        Me.Label_FramesPerSec.TabIndex = 65
        Me.Label_FramesPerSec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'GroupBox_VideoInDevice
        '
        Me.GroupBox_VideoInDevice.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_VideoInDevice.Controls.Add(Me.Label_Millisec)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.Label_Resolution)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.ComboBox_VideoInputDevice)
        Me.GroupBox_VideoInDevice.Controls.Add(Me.Label_FramesPerSec)
        Me.GroupBox_VideoInDevice.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_VideoInDevice.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_VideoInDevice.Location = New System.Drawing.Point(6, 52)
        Me.GroupBox_VideoInDevice.Name = "GroupBox_VideoInDevice"
        Me.GroupBox_VideoInDevice.Size = New System.Drawing.Size(297, 77)
        Me.GroupBox_VideoInDevice.TabIndex = 70
        Me.GroupBox_VideoInDevice.TabStop = False
        Me.GroupBox_VideoInDevice.Text = "Video Input Device"
        '
        'Label_Millisec
        '
        Me.Label_Millisec.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label_Millisec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Millisec.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Millisec.Location = New System.Drawing.Point(131, 51)
        Me.Label_Millisec.Name = "Label_Millisec"
        Me.Label_Millisec.Size = New System.Drawing.Size(54, 16)
        Me.Label_Millisec.TabIndex = 69
        Me.Label_Millisec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Resolution
        '
        Me.Label_Resolution.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label_Resolution.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label_Resolution.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Resolution.Location = New System.Drawing.Point(12, 51)
        Me.Label_Resolution.Name = "Label_Resolution"
        Me.Label_Resolution.Size = New System.Drawing.Size(70, 16)
        Me.Label_Resolution.TabIndex = 66
        Me.Label_Resolution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_File, Me.Menu_Tools, Me.Menu_Language, Me.Menu_Help, Me.Menu_About})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(651, 24)
        Me.MenuStrip1.TabIndex = 72
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Menu_File
        '
        Me.Menu_File.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator3, Me.Menu_File_Exit})
        Me.Menu_File.Name = "Menu_File"
        Me.Menu_File.Size = New System.Drawing.Size(37, 20)
        Me.Menu_File.Text = "File"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(90, 6)
        '
        'Menu_File_Exit
        '
        Me.Menu_File_Exit.Name = "Menu_File_Exit"
        Me.Menu_File_Exit.Size = New System.Drawing.Size(93, 22)
        Me.Menu_File_Exit.Text = "Exit"
        '
        'Menu_Tools
        '
        Me.Menu_Tools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Tools_VideoinControls, Me.Menu_Tools_TrimPoints, Me.Menu_Tools_Separator})
        Me.Menu_Tools.Name = "Menu_Tools"
        Me.Menu_Tools.Size = New System.Drawing.Size(46, 20)
        Me.Menu_Tools.Text = "Tools"
        '
        'Menu_Tools_VideoinControls
        '
        Me.Menu_Tools_VideoinControls.Image = CType(resources.GetObject("Menu_Tools_VideoinControls.Image"), System.Drawing.Image)
        Me.Menu_Tools_VideoinControls.Name = "Menu_Tools_VideoinControls"
        Me.Menu_Tools_VideoinControls.Size = New System.Drawing.Size(169, 22)
        Me.Menu_Tools_VideoinControls.Text = "Video-in Controls"
        '
        'Menu_Tools_TrimPoints
        '
        Me.Menu_Tools_TrimPoints.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Tools_Trim1, Me.Menu_Tools_Trim2, Me.Menu_Tools_TrimSelect})
        Me.Menu_Tools_TrimPoints.Name = "Menu_Tools_TrimPoints"
        Me.Menu_Tools_TrimPoints.Size = New System.Drawing.Size(169, 22)
        Me.Menu_Tools_TrimPoints.Text = "Trim points"
        '
        'Menu_Tools_Trim1
        '
        Me.Menu_Tools_Trim1.Name = "Menu_Tools_Trim1"
        Me.Menu_Tools_Trim1.Size = New System.Drawing.Size(218, 22)
        Me.Menu_Tools_Trim1.Text = "Fluorescent 436 546"
        '
        'Menu_Tools_Trim2
        '
        Me.Menu_Tools_Trim2.Name = "Menu_Tools_Trim2"
        Me.Menu_Tools_Trim2.Size = New System.Drawing.Size(218, 22)
        Me.Menu_Tools_Trim2.Text = "Fluorescent 436 692"
        '
        'Menu_Tools_TrimSelect
        '
        Me.Menu_Tools_TrimSelect.Name = "Menu_Tools_TrimSelect"
        Me.Menu_Tools_TrimSelect.Size = New System.Drawing.Size(218, 22)
        Me.Menu_Tools_TrimSelect.Text = "Select trim points manually"
        '
        'Menu_Tools_Separator
        '
        Me.Menu_Tools_Separator.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Tools_SeparatorTab, Me.Menu_Tools_SeparatorSemicolon, Me.Menu_Tools_SeparatorComma})
        Me.Menu_Tools_Separator.Name = "Menu_Tools_Separator"
        Me.Menu_Tools_Separator.Size = New System.Drawing.Size(169, 22)
        Me.Menu_Tools_Separator.Text = "DataFile Separator"
        '
        'Menu_Tools_SeparatorTab
        '
        Me.Menu_Tools_SeparatorTab.Name = "Menu_Tools_SeparatorTab"
        Me.Menu_Tools_SeparatorTab.Size = New System.Drawing.Size(191, 22)
        Me.Menu_Tools_SeparatorTab.Text = "Single TAB"
        '
        'Menu_Tools_SeparatorSemicolon
        '
        Me.Menu_Tools_SeparatorSemicolon.Name = "Menu_Tools_SeparatorSemicolon"
        Me.Menu_Tools_SeparatorSemicolon.Size = New System.Drawing.Size(191, 22)
        Me.Menu_Tools_SeparatorSemicolon.Text = "Semicolon and spaces"
        '
        'Menu_Tools_SeparatorComma
        '
        Me.Menu_Tools_SeparatorComma.Name = "Menu_Tools_SeparatorComma"
        Me.Menu_Tools_SeparatorComma.Size = New System.Drawing.Size(191, 22)
        Me.Menu_Tools_SeparatorComma.Text = "Comma and spaces"
        '
        'Menu_Language
        '
        Me.Menu_Language.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Language_ENG, Me.Menu_Language_ITA, Me.Menu_Language_FRA, Me.Menu_Language_ESP, Me.Menu_Language_POR, Me.Menu_Language_DEU, Me.Menu_Language_JPN, Me.Menu_Language_CHI})
        Me.Menu_Language.Name = "Menu_Language"
        Me.Menu_Language.Size = New System.Drawing.Size(71, 20)
        Me.Menu_Language.Text = "Language"
        '
        'Menu_Language_ENG
        '
        Me.Menu_Language_ENG.Image = CType(resources.GetObject("Menu_Language_ENG.Image"), System.Drawing.Image)
        Me.Menu_Language_ENG.Name = "Menu_Language_ENG"
        Me.Menu_Language_ENG.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_ENG.Text = "English"
        '
        'Menu_Language_ITA
        '
        Me.Menu_Language_ITA.Image = CType(resources.GetObject("Menu_Language_ITA.Image"), System.Drawing.Image)
        Me.Menu_Language_ITA.Name = "Menu_Language_ITA"
        Me.Menu_Language_ITA.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_ITA.Text = "Italiano"
        '
        'Menu_Language_FRA
        '
        Me.Menu_Language_FRA.Image = CType(resources.GetObject("Menu_Language_FRA.Image"), System.Drawing.Image)
        Me.Menu_Language_FRA.Name = "Menu_Language_FRA"
        Me.Menu_Language_FRA.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_FRA.Text = "Francais"
        '
        'Menu_Language_ESP
        '
        Me.Menu_Language_ESP.Image = CType(resources.GetObject("Menu_Language_ESP.Image"), System.Drawing.Image)
        Me.Menu_Language_ESP.Name = "Menu_Language_ESP"
        Me.Menu_Language_ESP.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_ESP.Text = "Espanol"
        '
        'Menu_Language_POR
        '
        Me.Menu_Language_POR.Image = CType(resources.GetObject("Menu_Language_POR.Image"), System.Drawing.Image)
        Me.Menu_Language_POR.Name = "Menu_Language_POR"
        Me.Menu_Language_POR.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_POR.Text = "Portoguese"
        '
        'Menu_Language_DEU
        '
        Me.Menu_Language_DEU.Image = CType(resources.GetObject("Menu_Language_DEU.Image"), System.Drawing.Image)
        Me.Menu_Language_DEU.Name = "Menu_Language_DEU"
        Me.Menu_Language_DEU.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_DEU.Text = "Deutsch"
        '
        'Menu_Language_JPN
        '
        Me.Menu_Language_JPN.Image = CType(resources.GetObject("Menu_Language_JPN.Image"), System.Drawing.Image)
        Me.Menu_Language_JPN.Name = "Menu_Language_JPN"
        Me.Menu_Language_JPN.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_JPN.Text = "Japanese"
        '
        'Menu_Language_CHI
        '
        Me.Menu_Language_CHI.Image = CType(resources.GetObject("Menu_Language_CHI.Image"), System.Drawing.Image)
        Me.Menu_Language_CHI.Name = "Menu_Language_CHI"
        Me.Menu_Language_CHI.Size = New System.Drawing.Size(134, 22)
        Me.Menu_Language_CHI.Text = "Chinese"
        '
        'Menu_Help
        '
        Me.Menu_Help.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Menu_Help_ProgramHelp, Me.ToolStripSeparator4, Me.Menu_Help_Technology, Me.Menu_Help_Construction, Me.Menu_Help_Spectrums, Me.ToolStripSeparator6, Me.Menu_Help_OpenProgramFolder})
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(44, 20)
        Me.Menu_Help.Text = "Help"
        '
        'Menu_Help_ProgramHelp
        '
        Me.Menu_Help_ProgramHelp.Image = CType(resources.GetObject("Menu_Help_ProgramHelp.Image"), System.Drawing.Image)
        Me.Menu_Help_ProgramHelp.Name = "Menu_Help_ProgramHelp"
        Me.Menu_Help_ProgramHelp.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_ProgramHelp.Text = "Program help"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(183, 6)
        '
        'Menu_Help_Technology
        '
        Me.Menu_Help_Technology.Image = CType(resources.GetObject("Menu_Help_Technology.Image"), System.Drawing.Image)
        Me.Menu_Help_Technology.Name = "Menu_Help_Technology"
        Me.Menu_Help_Technology.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_Technology.Text = "Technology"
        '
        'Menu_Help_Construction
        '
        Me.Menu_Help_Construction.Image = CType(resources.GetObject("Menu_Help_Construction.Image"), System.Drawing.Image)
        Me.Menu_Help_Construction.Name = "Menu_Help_Construction"
        Me.Menu_Help_Construction.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_Construction.Text = "Construction"
        '
        'Menu_Help_Spectrums
        '
        Me.Menu_Help_Spectrums.Image = CType(resources.GetObject("Menu_Help_Spectrums.Image"), System.Drawing.Image)
        Me.Menu_Help_Spectrums.Name = "Menu_Help_Spectrums"
        Me.Menu_Help_Spectrums.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_Spectrums.Text = "Example spectrums"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(183, 6)
        '
        'Menu_Help_OpenProgramFolder
        '
        Me.Menu_Help_OpenProgramFolder.Image = CType(resources.GetObject("Menu_Help_OpenProgramFolder.Image"), System.Drawing.Image)
        Me.Menu_Help_OpenProgramFolder.Name = "Menu_Help_OpenProgramFolder"
        Me.Menu_Help_OpenProgramFolder.Size = New System.Drawing.Size(186, 22)
        Me.Menu_Help_OpenProgramFolder.Text = "Open program folder"
        '
        'Menu_About
        '
        Me.Menu_About.Name = "Menu_About"
        Me.Menu_About.Size = New System.Drawing.Size(52, 20)
        Me.Menu_About.Text = "About"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tool_VideoControls, Me.ToolStripSeparator2, Me.Tools_SaveSpectrum, Me.ToolStripSeparator1, Me.Tools_SaveCamera, Me.ToolStripSeparator5, Me.Tools_SaveTotal, Me.Tools_Run, Me.ToolStripSeparator7, Me.Tools_SaveDataFile})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(651, 25)
        Me.ToolStrip1.TabIndex = 73
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Tool_VideoControls
        '
        Me.Tool_VideoControls.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Tool_VideoControls.Image = CType(resources.GetObject("Tool_VideoControls.Image"), System.Drawing.Image)
        Me.Tool_VideoControls.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tool_VideoControls.Name = "Tool_VideoControls"
        Me.Tool_VideoControls.Size = New System.Drawing.Size(103, 22)
        Me.Tool_VideoControls.Text = "Video controls"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveSpectrum
        '
        Me.Tools_SaveSpectrum.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Tools_SaveSpectrum.Image = CType(resources.GetObject("Tools_SaveSpectrum.Image"), System.Drawing.Image)
        Me.Tools_SaveSpectrum.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveSpectrum.Name = "Tools_SaveSpectrum"
        Me.Tools_SaveSpectrum.Size = New System.Drawing.Size(114, 22)
        Me.Tools_SaveSpectrum.Text = "Spectrum image"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveCamera
        '
        Me.Tools_SaveCamera.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Tools_SaveCamera.Image = CType(resources.GetObject("Tools_SaveCamera.Image"), System.Drawing.Image)
        Me.Tools_SaveCamera.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveCamera.Name = "Tools_SaveCamera"
        Me.Tools_SaveCamera.Size = New System.Drawing.Size(104, 22)
        Me.Tools_SaveCamera.Text = "Camera image"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveTotal
        '
        Me.Tools_SaveTotal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Tools_SaveTotal.Image = CType(resources.GetObject("Tools_SaveTotal.Image"), System.Drawing.Image)
        Me.Tools_SaveTotal.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveTotal.Name = "Tools_SaveTotal"
        Me.Tools_SaveTotal.Size = New System.Drawing.Size(88, 22)
        Me.Tools_SaveTotal.Text = "Total image"
        '
        'Tools_Run
        '
        Me.Tools_Run.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Tools_Run.Checked = True
        Me.Tools_Run.CheckOnClick = True
        Me.Tools_Run.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Tools_Run.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Tools_Run.Image = CType(resources.GetObject("Tools_Run.Image"), System.Drawing.Image)
        Me.Tools_Run.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_Run.Margin = New System.Windows.Forms.Padding(4, 1, 10, 2)
        Me.Tools_Run.Name = "Tools_Run"
        Me.Tools_Run.Padding = New System.Windows.Forms.Padding(8, 0, 0, 0)
        Me.Tools_Run.Size = New System.Drawing.Size(56, 22)
        Me.Tools_Run.Text = "Run"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'Tools_SaveDataFile
        '
        Me.Tools_SaveDataFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Tools_SaveDataFile.Image = CType(resources.GetObject("Tools_SaveDataFile.Image"), System.Drawing.Image)
        Me.Tools_SaveDataFile.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tools_SaveDataFile.Name = "Tools_SaveDataFile"
        Me.Tools_SaveDataFile.Size = New System.Drawing.Size(96, 22)
        Me.Tools_SaveDataFile.Text = "Save DataFile"
        '
        'Timer_1Hz
        '
        '
        'GroupBox_Input
        '
        Me.GroupBox_Input.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Input.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_Input.Controls.Add(Me.txt_SizeY)
        Me.GroupBox_Input.Controls.Add(Me.txt_StartX)
        Me.GroupBox_Input.Controls.Add(Me.txt_EndX)
        Me.GroupBox_Input.Controls.Add(Me.txt_StartY)
        Me.GroupBox_Input.Controls.Add(Me.Label_SizeY)
        Me.GroupBox_Input.Controls.Add(Me.Label_StartX)
        Me.GroupBox_Input.Controls.Add(Me.PBox_Camera)
        Me.GroupBox_Input.Controls.Add(Me.Label_StartY)
        Me.GroupBox_Input.Controls.Add(Me.Label_EndX)
        Me.GroupBox_Input.Controls.Add(Me.chk_Flip)
        Me.GroupBox_Input.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Input.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_Input.Location = New System.Drawing.Point(309, 52)
        Me.GroupBox_Input.Name = "GroupBox_Input"
        Me.GroupBox_Input.Size = New System.Drawing.Size(336, 297)
        Me.GroupBox_Input.TabIndex = 92
        Me.GroupBox_Input.TabStop = False
        Me.GroupBox_Input.Text = "Input"
        '
        'Label_SizeY
        '
        Me.Label_SizeY.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label_SizeY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SizeY.ForeColor = System.Drawing.Color.Black
        Me.Label_SizeY.Location = New System.Drawing.Point(3, 103)
        Me.Label_SizeY.Name = "Label_SizeY"
        Me.Label_SizeY.Size = New System.Drawing.Size(53, 13)
        Me.Label_SizeY.TabIndex = 101
        Me.Label_SizeY.Text = "Size Y"
        Me.Label_SizeY.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label_StartX
        '
        Me.Label_StartX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label_StartX.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_StartX.ForeColor = System.Drawing.Color.Black
        Me.Label_StartX.Location = New System.Drawing.Point(29, 276)
        Me.Label_StartX.Name = "Label_StartX"
        Me.Label_StartX.Size = New System.Drawing.Size(72, 13)
        Me.Label_StartX.TabIndex = 99
        Me.Label_StartX.Text = "Start X"
        Me.Label_StartX.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_StartY
        '
        Me.Label_StartY.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label_StartY.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_StartY.ForeColor = System.Drawing.Color.Black
        Me.Label_StartY.Location = New System.Drawing.Point(5, 162)
        Me.Label_StartY.Name = "Label_StartY"
        Me.Label_StartY.Size = New System.Drawing.Size(52, 13)
        Me.Label_StartY.TabIndex = 97
        Me.Label_StartY.Text = "Start Y"
        Me.Label_StartY.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label_EndX
        '
        Me.Label_EndX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_EndX.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_EndX.ForeColor = System.Drawing.Color.Black
        Me.Label_EndX.Location = New System.Drawing.Point(219, 276)
        Me.Label_EndX.Name = "Label_EndX"
        Me.Label_EndX.Size = New System.Drawing.Size(67, 13)
        Me.Label_EndX.TabIndex = 95
        Me.Label_EndX.Text = "End X"
        Me.Label_EndX.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'chk_Flip
        '
        Me.chk_Flip.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chk_Flip.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_Flip.ForeColor = System.Drawing.Color.Black
        Me.chk_Flip.Location = New System.Drawing.Point(6, 33)
        Me.chk_Flip.Name = "chk_Flip"
        Me.chk_Flip.Size = New System.Drawing.Size(46, 17)
        Me.chk_Flip.TabIndex = 92
        Me.chk_Flip.Text = "Flip"
        Me.chk_Flip.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.chk_Flip.UseVisualStyleBackColor = True
        '
        'Label_RisingSpeed
        '
        Me.Label_RisingSpeed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_RisingSpeed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_RisingSpeed.ForeColor = System.Drawing.Color.Black
        Me.Label_RisingSpeed.Location = New System.Drawing.Point(155, 20)
        Me.Label_RisingSpeed.Name = "Label_RisingSpeed"
        Me.Label_RisingSpeed.Size = New System.Drawing.Size(96, 13)
        Me.Label_RisingSpeed.TabIndex = 103
        Me.Label_RisingSpeed.Text = "Rising speed"
        Me.Label_RisingSpeed.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_JpegQuality
        '
        Me.Label_JpegQuality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_JpegQuality.ForeColor = System.Drawing.Color.Black
        Me.Label_JpegQuality.Location = New System.Drawing.Point(154, 15)
        Me.Label_JpegQuality.Name = "Label_JpegQuality"
        Me.Label_JpegQuality.Size = New System.Drawing.Size(93, 13)
        Me.Label_JpegQuality.TabIndex = 101
        Me.Label_JpegQuality.Text = "JPEG quality"
        Me.Label_JpegQuality.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_Path
        '
        Me.Label_Path.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Path.ForeColor = System.Drawing.Color.Black
        Me.Label_Path.Location = New System.Drawing.Point(16, 62)
        Me.Label_Path.Name = "Label_Path"
        Me.Label_Path.Size = New System.Drawing.Size(260, 13)
        Me.Label_Path.TabIndex = 100
        Me.Label_Path.Text = "Path for Images and Spectrum File"
        '
        'Label_Name
        '
        Me.Label_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Name.ForeColor = System.Drawing.Color.Black
        Me.Label_Name.Location = New System.Drawing.Point(16, 22)
        Me.Label_Name.Name = "Label_Name"
        Me.Label_Name.Size = New System.Drawing.Size(65, 13)
        Me.Label_Name.TabIndex = 98
        Me.Label_Name.Text = "Name"
        '
        'LabelDot
        '
        Me.LabelDot.AutoSize = True
        Me.LabelDot.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDot.Location = New System.Drawing.Point(198, 39)
        Me.LabelDot.Name = "LabelDot"
        Me.LabelDot.Size = New System.Drawing.Size(13, 16)
        Me.LabelDot.TabIndex = 96
        Me.LabelDot.Text = "."
        '
        'GroupBox_SaveImage
        '
        Me.GroupBox_SaveImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_SaveImage.Controls.Add(Me.txt_JpegQuality)
        Me.GroupBox_SaveImage.Controls.Add(Me.Label_JpegQuality)
        Me.GroupBox_SaveImage.Controls.Add(Me.LabelDot)
        Me.GroupBox_SaveImage.Controls.Add(Me.txt_FilePath)
        Me.GroupBox_SaveImage.Controls.Add(Me.txt_FileName)
        Me.GroupBox_SaveImage.Controls.Add(Me.Label_Name)
        Me.GroupBox_SaveImage.Controls.Add(Me.ComboBox_FileType)
        Me.GroupBox_SaveImage.Controls.Add(Me.Label_Path)
        Me.GroupBox_SaveImage.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_SaveImage.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_SaveImage.Location = New System.Drawing.Point(6, 135)
        Me.GroupBox_SaveImage.Name = "GroupBox_SaveImage"
        Me.GroupBox_SaveImage.Size = New System.Drawing.Size(297, 114)
        Me.GroupBox_SaveImage.TabIndex = 95
        Me.GroupBox_SaveImage.TabStop = False
        Me.GroupBox_SaveImage.Text = "Save image"
        '
        'PBox_Spectrum
        '
        Me.PBox_Spectrum.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PBox_Spectrum.BackColor = System.Drawing.Color.Cornsilk
        Me.PBox_Spectrum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PBox_Spectrum.ErrorImage = Nothing
        Me.PBox_Spectrum.InitialImage = Nothing
        Me.PBox_Spectrum.Location = New System.Drawing.Point(6, 355)
        Me.PBox_Spectrum.Name = "PBox_Spectrum"
        Me.PBox_Spectrum.Size = New System.Drawing.Size(622, 180)
        Me.PBox_Spectrum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PBox_Spectrum.TabIndex = 96
        Me.PBox_Spectrum.TabStop = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.LightYellow
        Me.StatusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 539)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.StatusStrip1.Size = New System.Drawing.Size(651, 22)
        Me.StatusStrip1.TabIndex = 97
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.Cornsilk
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox3.ErrorImage = Nothing
        Me.PictureBox3.InitialImage = Nothing
        Me.PictureBox3.Location = New System.Drawing.Point(632, 355)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(13, 181)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3.TabIndex = 104
        Me.PictureBox3.TabStop = False
        '
        'Label_Filter
        '
        Me.Label_Filter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_Filter.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Filter.ForeColor = System.Drawing.Color.Black
        Me.Label_Filter.Location = New System.Drawing.Point(458, 5)
        Me.Label_Filter.Name = "Label_Filter"
        Me.Label_Filter.Size = New System.Drawing.Size(39, 13)
        Me.Label_Filter.TabIndex = 106
        Me.Label_Filter.Text = "Filter"
        Me.Label_Filter.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.LightYellow
        Me.Panel1.Controls.Add(Me.txt_Filter)
        Me.Panel1.Controls.Add(Me.btn_Reference)
        Me.Panel1.Controls.Add(Me.Label_MaxPeak)
        Me.Panel1.Controls.Add(Me.btn_Dips)
        Me.Panel1.Controls.Add(Me.btn_Colors)
        Me.Panel1.Controls.Add(Me.btn_Peaks)
        Me.Panel1.Controls.Add(Me.btn_TrimScale)
        Me.Panel1.Controls.Add(Me.Label_Filter)
        Me.Panel1.Location = New System.Drawing.Point(1, 537)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(632, 24)
        Me.Panel1.TabIndex = 112
        '
        'Label_FallingSpeed
        '
        Me.Label_FallingSpeed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_FallingSpeed.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FallingSpeed.ForeColor = System.Drawing.Color.Black
        Me.Label_FallingSpeed.Location = New System.Drawing.Point(155, 42)
        Me.Label_FallingSpeed.Name = "Label_FallingSpeed"
        Me.Label_FallingSpeed.Size = New System.Drawing.Size(96, 13)
        Me.Label_FallingSpeed.TabIndex = 115
        Me.Label_FallingSpeed.Text = "Falling speed"
        Me.Label_FallingSpeed.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_MaxPeak
        '
        Me.Label_MaxPeak.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_MaxPeak.ForeColor = System.Drawing.Color.Black
        Me.Label_MaxPeak.Location = New System.Drawing.Point(6, 6)
        Me.Label_MaxPeak.Name = "Label_MaxPeak"
        Me.Label_MaxPeak.Size = New System.Drawing.Size(128, 13)
        Me.Label_MaxPeak.TabIndex = 112
        '
        'Label_SlotWriteFile
        '
        Me.Label_SlotWriteFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_SlotWriteFile.BackColor = System.Drawing.Color.Transparent
        Me.Label_SlotWriteFile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SlotWriteFile.ForeColor = System.Drawing.Color.Black
        Me.Label_SlotWriteFile.Location = New System.Drawing.Point(6, 68)
        Me.Label_SlotWriteFile.Name = "Label_SlotWriteFile"
        Me.Label_SlotWriteFile.Size = New System.Drawing.Size(88, 16)
        Me.Label_SlotWriteFile.TabIndex = 114
        Me.Label_SlotWriteFile.Text = "Slot WriteFile"
        Me.Label_SlotWriteFile.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_SlotRun
        '
        Me.Label_SlotRun.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_SlotRun.BackColor = System.Drawing.Color.Transparent
        Me.Label_SlotRun.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SlotRun.ForeColor = System.Drawing.Color.Black
        Me.Label_SlotRun.Location = New System.Drawing.Point(6, 24)
        Me.Label_SlotRun.Name = "Label_SlotRun"
        Me.Label_SlotRun.Size = New System.Drawing.Size(89, 16)
        Me.Label_SlotRun.TabIndex = 116
        Me.Label_SlotRun.Text = "Slot Run"
        Me.Label_SlotRun.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label_SlotStop
        '
        Me.Label_SlotStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_SlotStop.BackColor = System.Drawing.Color.Transparent
        Me.Label_SlotStop.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_SlotStop.ForeColor = System.Drawing.Color.Black
        Me.Label_SlotStop.Location = New System.Drawing.Point(6, 46)
        Me.Label_SlotStop.Name = "Label_SlotStop"
        Me.Label_SlotStop.Size = New System.Drawing.Size(89, 16)
        Me.Label_SlotStop.TabIndex = 118
        Me.Label_SlotStop.Text = "Slot Stop"
        Me.Label_SlotStop.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'GroupBox_SyncAndIntegration
        '
        Me.GroupBox_SyncAndIntegration.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.txt_FallingSpeed)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.txt_SlotStop)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.Label_SlotStop)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.txt_SlotRun)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.txt_SlotWriteFile)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.btn_ResetSpectrumData)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.Label_SlotRun)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.Label_FallingSpeed)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.Label_RisingSpeed)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.txt_RisingSpeed)
        Me.GroupBox_SyncAndIntegration.Controls.Add(Me.Label_SlotWriteFile)
        Me.GroupBox_SyncAndIntegration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_SyncAndIntegration.ForeColor = System.Drawing.Color.DarkBlue
        Me.GroupBox_SyncAndIntegration.Location = New System.Drawing.Point(6, 255)
        Me.GroupBox_SyncAndIntegration.Name = "GroupBox_SyncAndIntegration"
        Me.GroupBox_SyncAndIntegration.Size = New System.Drawing.Size(297, 94)
        Me.GroupBox_SyncAndIntegration.TabIndex = 119
        Me.GroupBox_SyncAndIntegration.TabStop = False
        Me.GroupBox_SyncAndIntegration.Text = "Sync and integration controls"
        '
        'txt_FallingSpeed
        '
        Me.txt_FallingSpeed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_FallingSpeed.ArrowsIncrement = 1
        Me.txt_FallingSpeed.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_FallingSpeed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FallingSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FallingSpeed.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FallingSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_FallingSpeed.Increment = 0.2
        Me.txt_FallingSpeed.Location = New System.Drawing.Point(254, 40)
        Me.txt_FallingSpeed.MaxValue = 100
        Me.txt_FallingSpeed.MinValue = 0
        Me.txt_FallingSpeed.Multiline = True
        Me.txt_FallingSpeed.Name = "txt_FallingSpeed"
        Me.txt_FallingSpeed.NumericValue = 30
        Me.txt_FallingSpeed.NumericValueInteger = 30
        Me.txt_FallingSpeed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FallingSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FallingSpeed.RoundingStep = 0
        Me.txt_FallingSpeed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FallingSpeed.Size = New System.Drawing.Size(30, 16)
        Me.txt_FallingSpeed.SuppressZeros = True
        Me.txt_FallingSpeed.TabIndex = 114
        Me.txt_FallingSpeed.Text = "30"
        Me.txt_FallingSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotStop
        '
        Me.txt_SlotStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_SlotStop.ArrowsIncrement = 1
        Me.txt_SlotStop.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_SlotStop.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotStop.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotStop.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotStop.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotStop.Increment = 0.2
        Me.txt_SlotStop.Location = New System.Drawing.Point(97, 44)
        Me.txt_SlotStop.MaxValue = 999
        Me.txt_SlotStop.MinValue = -1
        Me.txt_SlotStop.Multiline = True
        Me.txt_SlotStop.Name = "txt_SlotStop"
        Me.txt_SlotStop.NumericValue = -1
        Me.txt_SlotStop.NumericValueInteger = -1
        Me.txt_SlotStop.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotStop.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotStop.RoundingStep = 0
        Me.txt_SlotStop.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotStop.Size = New System.Drawing.Size(36, 17)
        Me.txt_SlotStop.SuppressZeros = True
        Me.txt_SlotStop.TabIndex = 117
        Me.txt_SlotStop.Text = "-1"
        Me.txt_SlotStop.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotRun
        '
        Me.txt_SlotRun.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_SlotRun.ArrowsIncrement = 1
        Me.txt_SlotRun.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_SlotRun.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotRun.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotRun.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotRun.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotRun.Increment = 0.2
        Me.txt_SlotRun.Location = New System.Drawing.Point(97, 22)
        Me.txt_SlotRun.MaxValue = 999
        Me.txt_SlotRun.MinValue = -1
        Me.txt_SlotRun.Multiline = True
        Me.txt_SlotRun.Name = "txt_SlotRun"
        Me.txt_SlotRun.NumericValue = -1
        Me.txt_SlotRun.NumericValueInteger = -1
        Me.txt_SlotRun.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotRun.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotRun.RoundingStep = 0
        Me.txt_SlotRun.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotRun.Size = New System.Drawing.Size(36, 17)
        Me.txt_SlotRun.SuppressZeros = True
        Me.txt_SlotRun.TabIndex = 115
        Me.txt_SlotRun.Text = "-1"
        Me.txt_SlotRun.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_SlotWriteFile
        '
        Me.txt_SlotWriteFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_SlotWriteFile.ArrowsIncrement = 1
        Me.txt_SlotWriteFile.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_SlotWriteFile.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SlotWriteFile.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SlotWriteFile.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SlotWriteFile.ForeColor = System.Drawing.Color.Black
        Me.txt_SlotWriteFile.Increment = 0.2
        Me.txt_SlotWriteFile.Location = New System.Drawing.Point(97, 66)
        Me.txt_SlotWriteFile.MaxValue = 999
        Me.txt_SlotWriteFile.MinValue = -1
        Me.txt_SlotWriteFile.Multiline = True
        Me.txt_SlotWriteFile.Name = "txt_SlotWriteFile"
        Me.txt_SlotWriteFile.NumericValue = -1
        Me.txt_SlotWriteFile.NumericValueInteger = -1
        Me.txt_SlotWriteFile.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SlotWriteFile.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SlotWriteFile.RoundingStep = 0
        Me.txt_SlotWriteFile.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SlotWriteFile.Size = New System.Drawing.Size(36, 17)
        Me.txt_SlotWriteFile.SuppressZeros = True
        Me.txt_SlotWriteFile.TabIndex = 113
        Me.txt_SlotWriteFile.Text = "-1"
        Me.txt_SlotWriteFile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_ResetSpectrumData
        '
        Me.btn_ResetSpectrumData.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_ResetSpectrumData.BorderShow = False
        DesignerRectTracker11.IsActive = False
        DesignerRectTracker11.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker11.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ResetSpectrumData.CenterPtTracker = DesignerRectTracker11
        CBlendItems11.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems11.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_ResetSpectrumData.ColorFillBlend = CBlendItems11
        CBlendItems12.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems12.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_ResetSpectrumData.ColorFillBlendChecked = CBlendItems12
        Me.btn_ResetSpectrumData.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_ResetSpectrumData.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_ResetSpectrumData.Corners.All = CType(4, Short)
        Me.btn_ResetSpectrumData.Corners.LowerLeft = CType(4, Short)
        Me.btn_ResetSpectrumData.Corners.LowerRight = CType(4, Short)
        Me.btn_ResetSpectrumData.Corners.UpperLeft = CType(4, Short)
        Me.btn_ResetSpectrumData.Corners.UpperRight = CType(4, Short)
        Me.btn_ResetSpectrumData.DimFactorOver = 30
        Me.btn_ResetSpectrumData.FillType = Theremino_Spectrometer.MyButton.eFillType.LinearVertical
        Me.btn_ResetSpectrumData.FillTypeChecked = Theremino_Spectrometer.MyButton.eFillType.GradientPath
        Me.btn_ResetSpectrumData.FocalPoints.CenterPtX = 0.8285714!
        Me.btn_ResetSpectrumData.FocalPoints.CenterPtY = 1.0!
        Me.btn_ResetSpectrumData.FocalPoints.FocusPtX = 0.0!
        Me.btn_ResetSpectrumData.FocalPoints.FocusPtY = 0.0!
        Me.btn_ResetSpectrumData.FocalPointsChecked.CenterPtX = 0.492163!
        Me.btn_ResetSpectrumData.FocalPointsChecked.CenterPtY = 0.4722222!
        Me.btn_ResetSpectrumData.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.btn_ResetSpectrumData.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker12.IsActive = False
        DesignerRectTracker12.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker12.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_ResetSpectrumData.FocusPtTracker = DesignerRectTracker12
        Me.btn_ResetSpectrumData.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ResetSpectrumData.ForeColor = System.Drawing.Color.Black
        Me.btn_ResetSpectrumData.Image = Nothing
        Me.btn_ResetSpectrumData.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ResetSpectrumData.ImageIndex = 0
        Me.btn_ResetSpectrumData.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_ResetSpectrumData.Location = New System.Drawing.Point(149, 64)
        Me.btn_ResetSpectrumData.Name = "btn_ResetSpectrumData"
        Me.btn_ResetSpectrumData.Shape = Theremino_Spectrometer.MyButton.eShape.Rectangle
        Me.btn_ResetSpectrumData.SideImage = Nothing
        Me.btn_ResetSpectrumData.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_ResetSpectrumData.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_ResetSpectrumData.Size = New System.Drawing.Size(136, 21)
        Me.btn_ResetSpectrumData.TabIndex = 103
        Me.btn_ResetSpectrumData.Text = "Reset spectrum data"
        Me.btn_ResetSpectrumData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_ResetSpectrumData.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_ResetSpectrumData.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_ResetSpectrumData.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_RisingSpeed
        '
        Me.txt_RisingSpeed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_RisingSpeed.ArrowsIncrement = 1
        Me.txt_RisingSpeed.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_RisingSpeed.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_RisingSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_RisingSpeed.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_RisingSpeed.ForeColor = System.Drawing.Color.Black
        Me.txt_RisingSpeed.Increment = 0.2
        Me.txt_RisingSpeed.Location = New System.Drawing.Point(254, 18)
        Me.txt_RisingSpeed.MaxValue = 100
        Me.txt_RisingSpeed.MinValue = 1
        Me.txt_RisingSpeed.Multiline = True
        Me.txt_RisingSpeed.Name = "txt_RisingSpeed"
        Me.txt_RisingSpeed.NumericValue = 30
        Me.txt_RisingSpeed.NumericValueInteger = 30
        Me.txt_RisingSpeed.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_RisingSpeed.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_RisingSpeed.RoundingStep = 0
        Me.txt_RisingSpeed.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_RisingSpeed.Size = New System.Drawing.Size(30, 16)
        Me.txt_RisingSpeed.SuppressZeros = True
        Me.txt_RisingSpeed.TabIndex = 102
        Me.txt_RisingSpeed.Text = "30"
        Me.txt_RisingSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_Filter
        '
        Me.txt_Filter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_Filter.ArrowsIncrement = 1
        Me.txt_Filter.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_Filter.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_Filter.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_Filter.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Filter.Increment = 0.2
        Me.txt_Filter.Location = New System.Drawing.Point(499, 3)
        Me.txt_Filter.MaxValue = 100
        Me.txt_Filter.MinValue = 0
        Me.txt_Filter.Multiline = True
        Me.txt_Filter.Name = "txt_Filter"
        Me.txt_Filter.NumericValue = 30
        Me.txt_Filter.NumericValueInteger = 30
        Me.txt_Filter.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_Filter.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_Filter.RoundingStep = 0
        Me.txt_Filter.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_Filter.Size = New System.Drawing.Size(34, 16)
        Me.txt_Filter.SuppressZeros = True
        Me.txt_Filter.TabIndex = 105
        Me.txt_Filter.Text = "30"
        Me.txt_Filter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_Reference
        '
        Me.btn_Reference.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Reference.BorderShow = False
        DesignerRectTracker1.IsActive = True
        DesignerRectTracker1.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker1.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference.CenterPtTracker = DesignerRectTracker1
        Me.btn_Reference.CheckButton = True
        CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems1.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Reference.ColorFillBlend = CBlendItems1
        CBlendItems2.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems2.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_Reference.ColorFillBlendChecked = CBlendItems2
        Me.btn_Reference.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Reference.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Reference.Corners.All = CType(4, Short)
        Me.btn_Reference.Corners.LowerLeft = CType(4, Short)
        Me.btn_Reference.Corners.LowerRight = CType(4, Short)
        Me.btn_Reference.Corners.UpperLeft = CType(4, Short)
        Me.btn_Reference.Corners.UpperRight = CType(4, Short)
        Me.btn_Reference.DimFactorOver = 30
        Me.btn_Reference.FillType = Theremino_Spectrometer.MyButton.eFillType.LinearVertical
        Me.btn_Reference.FillTypeChecked = Theremino_Spectrometer.MyButton.eFillType.GradientPath
        Me.btn_Reference.FocalPoints.CenterPtX = 0.1363636!
        Me.btn_Reference.FocalPoints.CenterPtY = 1.0!
        Me.btn_Reference.FocalPoints.FocusPtX = 0.0!
        Me.btn_Reference.FocalPoints.FocusPtY = 0.0!
        Me.btn_Reference.FocalPointsChecked.CenterPtX = 0.492163!
        Me.btn_Reference.FocalPointsChecked.CenterPtY = 0.4722222!
        Me.btn_Reference.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.btn_Reference.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker2.IsActive = False
        DesignerRectTracker2.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker2.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Reference.FocusPtTracker = DesignerRectTracker2
        Me.btn_Reference.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Reference.ForeColor = System.Drawing.Color.Black
        Me.btn_Reference.Image = Nothing
        Me.btn_Reference.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference.ImageIndex = 0
        Me.btn_Reference.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Reference.Location = New System.Drawing.Point(197, 5)
        Me.btn_Reference.Name = "btn_Reference"
        Me.btn_Reference.Shape = Theremino_Spectrometer.MyButton.eShape.Rectangle
        Me.btn_Reference.SideImage = Nothing
        Me.btn_Reference.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Reference.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Reference.Size = New System.Drawing.Size(73, 16)
        Me.btn_Reference.TabIndex = 113
        Me.btn_Reference.Text = "Reference"
        Me.btn_Reference.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Reference.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Reference.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Reference.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Dips
        '
        Me.btn_Dips.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Dips.BorderShow = False
        DesignerRectTracker3.IsActive = False
        DesignerRectTracker3.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker3.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Dips.CenterPtTracker = DesignerRectTracker3
        Me.btn_Dips.CheckButton = True
        CBlendItems3.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems3.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Dips.ColorFillBlend = CBlendItems3
        CBlendItems4.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems4.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_Dips.ColorFillBlendChecked = CBlendItems4
        Me.btn_Dips.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Dips.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Dips.Corners.All = CType(4, Short)
        Me.btn_Dips.Corners.LowerLeft = CType(4, Short)
        Me.btn_Dips.Corners.LowerRight = CType(4, Short)
        Me.btn_Dips.Corners.UpperLeft = CType(4, Short)
        Me.btn_Dips.Corners.UpperRight = CType(4, Short)
        Me.btn_Dips.DimFactorOver = 30
        Me.btn_Dips.FillType = Theremino_Spectrometer.MyButton.eFillType.LinearVertical
        Me.btn_Dips.FillTypeChecked = Theremino_Spectrometer.MyButton.eFillType.GradientPath
        Me.btn_Dips.FocalPoints.CenterPtX = 0.1363636!
        Me.btn_Dips.FocalPoints.CenterPtY = 1.0!
        Me.btn_Dips.FocalPoints.FocusPtX = 0.0!
        Me.btn_Dips.FocalPoints.FocusPtY = 0.0!
        Me.btn_Dips.FocalPointsChecked.CenterPtX = 0.492163!
        Me.btn_Dips.FocalPointsChecked.CenterPtY = 0.4722222!
        Me.btn_Dips.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.btn_Dips.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker4.IsActive = False
        DesignerRectTracker4.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker4.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Dips.FocusPtTracker = DesignerRectTracker4
        Me.btn_Dips.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Dips.ForeColor = System.Drawing.Color.Black
        Me.btn_Dips.Image = Nothing
        Me.btn_Dips.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Dips.ImageIndex = 0
        Me.btn_Dips.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Dips.Location = New System.Drawing.Point(275, 5)
        Me.btn_Dips.Name = "btn_Dips"
        Me.btn_Dips.Shape = Theremino_Spectrometer.MyButton.eShape.Rectangle
        Me.btn_Dips.SideImage = Nothing
        Me.btn_Dips.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Dips.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Dips.Size = New System.Drawing.Size(46, 16)
        Me.btn_Dips.TabIndex = 110
        Me.btn_Dips.Text = "Dips"
        Me.btn_Dips.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Dips.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Dips.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Dips.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Colors
        '
        Me.btn_Colors.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Colors.BorderShow = False
        DesignerRectTracker5.IsActive = False
        DesignerRectTracker5.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker5.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Colors.CenterPtTracker = DesignerRectTracker5
        Me.btn_Colors.CheckButton = True
        Me.btn_Colors.Checked = True
        CBlendItems5.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems5.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Colors.ColorFillBlend = CBlendItems5
        CBlendItems6.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems6.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_Colors.ColorFillBlendChecked = CBlendItems6
        Me.btn_Colors.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Colors.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Colors.Corners.All = CType(4, Short)
        Me.btn_Colors.Corners.LowerLeft = CType(4, Short)
        Me.btn_Colors.Corners.LowerRight = CType(4, Short)
        Me.btn_Colors.Corners.UpperLeft = CType(4, Short)
        Me.btn_Colors.Corners.UpperRight = CType(4, Short)
        Me.btn_Colors.DimFactorOver = 30
        Me.btn_Colors.FillType = Theremino_Spectrometer.MyButton.eFillType.LinearVertical
        Me.btn_Colors.FillTypeChecked = Theremino_Spectrometer.MyButton.eFillType.GradientPath
        Me.btn_Colors.FocalPoints.CenterPtX = 0.1363636!
        Me.btn_Colors.FocalPoints.CenterPtY = 1.0!
        Me.btn_Colors.FocalPoints.FocusPtX = 0.0!
        Me.btn_Colors.FocalPoints.FocusPtY = 0.0!
        Me.btn_Colors.FocalPointsChecked.CenterPtX = 0.3269231!
        Me.btn_Colors.FocalPointsChecked.CenterPtY = 0.3125!
        Me.btn_Colors.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.btn_Colors.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker6.IsActive = False
        DesignerRectTracker6.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker6.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Colors.FocusPtTracker = DesignerRectTracker6
        Me.btn_Colors.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Colors.ForeColor = System.Drawing.Color.Black
        Me.btn_Colors.Image = Nothing
        Me.btn_Colors.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Colors.ImageIndex = 0
        Me.btn_Colors.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Colors.Location = New System.Drawing.Point(381, 5)
        Me.btn_Colors.Name = "btn_Colors"
        Me.btn_Colors.Shape = Theremino_Spectrometer.MyButton.eShape.Rectangle
        Me.btn_Colors.SideImage = Nothing
        Me.btn_Colors.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Colors.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Colors.Size = New System.Drawing.Size(56, 16)
        Me.btn_Colors.TabIndex = 111
        Me.btn_Colors.Text = "Colors"
        Me.btn_Colors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Colors.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Colors.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Colors.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_Peaks
        '
        Me.btn_Peaks.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_Peaks.BorderShow = False
        DesignerRectTracker7.IsActive = False
        DesignerRectTracker7.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker7.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Peaks.CenterPtTracker = DesignerRectTracker7
        Me.btn_Peaks.CheckButton = True
        Me.btn_Peaks.Checked = True
        CBlendItems7.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems7.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_Peaks.ColorFillBlend = CBlendItems7
        CBlendItems8.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems8.iPoint = New Single() {0.0!, -0.003021148!, 0.5!, 1.0!}
        Me.btn_Peaks.ColorFillBlendChecked = CBlendItems8
        Me.btn_Peaks.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_Peaks.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_Peaks.Corners.All = CType(4, Short)
        Me.btn_Peaks.Corners.LowerLeft = CType(4, Short)
        Me.btn_Peaks.Corners.LowerRight = CType(4, Short)
        Me.btn_Peaks.Corners.UpperLeft = CType(4, Short)
        Me.btn_Peaks.Corners.UpperRight = CType(4, Short)
        Me.btn_Peaks.DimFactorOver = 30
        Me.btn_Peaks.FillType = Theremino_Spectrometer.MyButton.eFillType.LinearVertical
        Me.btn_Peaks.FillTypeChecked = Theremino_Spectrometer.MyButton.eFillType.GradientPath
        Me.btn_Peaks.FocalPoints.CenterPtX = 0.1363636!
        Me.btn_Peaks.FocalPoints.CenterPtY = 1.0!
        Me.btn_Peaks.FocalPoints.FocusPtX = 0.0!
        Me.btn_Peaks.FocalPoints.FocusPtY = 0.0!
        Me.btn_Peaks.FocalPointsChecked.CenterPtX = 0.5869565!
        Me.btn_Peaks.FocalPointsChecked.CenterPtY = 0.125!
        Me.btn_Peaks.FocalPointsChecked.FocusPtX = 0.6!
        Me.btn_Peaks.FocalPointsChecked.FocusPtY = 0.4375!
        DesignerRectTracker8.IsActive = False
        DesignerRectTracker8.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker8.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_Peaks.FocusPtTracker = DesignerRectTracker8
        Me.btn_Peaks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Peaks.ForeColor = System.Drawing.Color.Black
        Me.btn_Peaks.Image = Nothing
        Me.btn_Peaks.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Peaks.ImageIndex = 0
        Me.btn_Peaks.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_Peaks.Location = New System.Drawing.Point(326, 5)
        Me.btn_Peaks.Name = "btn_Peaks"
        Me.btn_Peaks.Shape = Theremino_Spectrometer.MyButton.eShape.Rectangle
        Me.btn_Peaks.SideImage = Nothing
        Me.btn_Peaks.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Peaks.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_Peaks.Size = New System.Drawing.Size(50, 16)
        Me.btn_Peaks.TabIndex = 108
        Me.btn_Peaks.Text = "Peaks"
        Me.btn_Peaks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Peaks.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_Peaks.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_Peaks.TextShadow = System.Drawing.Color.Transparent
        '
        'btn_TrimScale
        '
        Me.btn_TrimScale.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_TrimScale.BorderShow = False
        DesignerRectTracker9.IsActive = False
        DesignerRectTracker9.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker9.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TrimScale.CenterPtTracker = DesignerRectTracker9
        Me.btn_TrimScale.CheckButton = True
        CBlendItems9.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(220, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))}
        CBlendItems9.iPoint = New Single() {0.0!, 0.5017921!, 1.0!}
        Me.btn_TrimScale.ColorFillBlend = CBlendItems9
        CBlendItems10.iColor = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(0, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(32, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(120, Byte), Integer))}
        CBlendItems10.iPoint = New Single() {0.0!, 0.5!, 1.0!}
        Me.btn_TrimScale.ColorFillBlendChecked = CBlendItems10
        Me.btn_TrimScale.ColorFillSolid = System.Drawing.SystemColors.Control
        Me.btn_TrimScale.ColorFillSolidChecked = System.Drawing.SystemColors.Control
        Me.btn_TrimScale.Corners.All = CType(4, Short)
        Me.btn_TrimScale.Corners.LowerLeft = CType(4, Short)
        Me.btn_TrimScale.Corners.LowerRight = CType(4, Short)
        Me.btn_TrimScale.Corners.UpperLeft = CType(4, Short)
        Me.btn_TrimScale.Corners.UpperRight = CType(4, Short)
        Me.btn_TrimScale.DimFactorOver = 30
        Me.btn_TrimScale.FillType = Theremino_Spectrometer.MyButton.eFillType.LinearVertical
        Me.btn_TrimScale.FillTypeChecked = Theremino_Spectrometer.MyButton.eFillType.GradientPath
        Me.btn_TrimScale.FocalPoints.CenterPtX = 0.5857143!
        Me.btn_TrimScale.FocalPoints.CenterPtY = 0.5!
        Me.btn_TrimScale.FocalPoints.FocusPtX = 0.0!
        Me.btn_TrimScale.FocalPoints.FocusPtY = 0.0!
        Me.btn_TrimScale.FocalPointsChecked.CenterPtX = 0.492163!
        Me.btn_TrimScale.FocalPointsChecked.CenterPtY = 0.4722222!
        Me.btn_TrimScale.FocalPointsChecked.FocusPtX = 0.8996865!
        Me.btn_TrimScale.FocalPointsChecked.FocusPtY = 0.4444444!
        DesignerRectTracker10.IsActive = True
        DesignerRectTracker10.TrackerRectangle = CType(resources.GetObject("DesignerRectTracker10.TrackerRectangle"), System.Drawing.RectangleF)
        Me.btn_TrimScale.FocusPtTracker = DesignerRectTracker10
        Me.btn_TrimScale.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_TrimScale.ForeColor = System.Drawing.Color.Black
        Me.btn_TrimScale.Image = Nothing
        Me.btn_TrimScale.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TrimScale.ImageIndex = 0
        Me.btn_TrimScale.ImageSize = New System.Drawing.Size(48, 48)
        Me.btn_TrimScale.Location = New System.Drawing.Point(551, 5)
        Me.btn_TrimScale.Name = "btn_TrimScale"
        Me.btn_TrimScale.Shape = Theremino_Spectrometer.MyButton.eShape.Rectangle
        Me.btn_TrimScale.SideImage = Nothing
        Me.btn_TrimScale.SideImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_TrimScale.SideImageSize = New System.Drawing.Size(32, 32)
        Me.btn_TrimScale.Size = New System.Drawing.Size(76, 16)
        Me.btn_TrimScale.TabIndex = 102
        Me.btn_TrimScale.Text = "Trim scale"
        Me.btn_TrimScale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_TrimScale.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        Me.btn_TrimScale.TextMargin = New System.Windows.Forms.Padding(0)
        Me.btn_TrimScale.TextShadow = System.Drawing.Color.Transparent
        '
        'txt_JpegQuality
        '
        Me.txt_JpegQuality.ArrowsIncrement = 1
        Me.txt_JpegQuality.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_JpegQuality.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_JpegQuality.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_JpegQuality.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_JpegQuality.ForeColor = System.Drawing.Color.Black
        Me.txt_JpegQuality.Increment = 0.2
        Me.txt_JpegQuality.Location = New System.Drawing.Point(245, 13)
        Me.txt_JpegQuality.MaxValue = 100
        Me.txt_JpegQuality.MinValue = 1
        Me.txt_JpegQuality.Multiline = True
        Me.txt_JpegQuality.Name = "txt_JpegQuality"
        Me.txt_JpegQuality.NumericValue = 100
        Me.txt_JpegQuality.NumericValueInteger = 100
        Me.txt_JpegQuality.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_JpegQuality.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_JpegQuality.RoundingStep = 0
        Me.txt_JpegQuality.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_JpegQuality.Size = New System.Drawing.Size(41, 19)
        Me.txt_JpegQuality.SuppressZeros = True
        Me.txt_JpegQuality.TabIndex = 102
        Me.txt_JpegQuality.Text = "100"
        Me.txt_JpegQuality.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_FilePath
        '
        Me.txt_FilePath.ArrowsIncrement = 0
        Me.txt_FilePath.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_FilePath.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FilePath.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FilePath.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FilePath.Increment = 0
        Me.txt_FilePath.Location = New System.Drawing.Point(15, 77)
        Me.txt_FilePath.MaxValue = 0
        Me.txt_FilePath.MinValue = 0
        Me.txt_FilePath.Multiline = True
        Me.txt_FilePath.Name = "txt_FilePath"
        Me.txt_FilePath.NumericValue = 0
        Me.txt_FilePath.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FilePath.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Solid
        Me.txt_FilePath.RoundingStep = 0
        Me.txt_FilePath.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FilePath.Size = New System.Drawing.Size(273, 28)
        Me.txt_FilePath.TabIndex = 97
        Me.txt_FilePath.Text = "   "
        Me.txt_FilePath.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_FileName
        '
        Me.txt_FileName.ArrowsIncrement = 0
        Me.txt_FileName.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_FileName.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_FileName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_FileName.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_FileName.Increment = 0
        Me.txt_FileName.Location = New System.Drawing.Point(12, 38)
        Me.txt_FileName.MaxValue = -1
        Me.txt_FileName.MinValue = -1
        Me.txt_FileName.Multiline = True
        Me.txt_FileName.Name = "txt_FileName"
        Me.txt_FileName.NumericValue = -1
        Me.txt_FileName.NumericValueInteger = -1
        Me.txt_FileName.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_FileName.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_FileName.RoundingStep = 0
        Me.txt_FileName.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_FileName.Size = New System.Drawing.Size(183, 16)
        Me.txt_FileName.SuppressZeros = True
        Me.txt_FileName.TabIndex = 99
        Me.txt_FileName.Text = "0"
        Me.txt_FileName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txt_FileName.WordWrap = False
        '
        'ComboBox_FileType
        '
        Me.ComboBox_FileType.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_FileType.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_FileType.BackColor = System.Drawing.Color.FloralWhite
        Me.ComboBox_FileType.BackColor_Focused = System.Drawing.SystemColors.Window
        Me.ComboBox_FileType.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_FileType.BorderColor = System.Drawing.Color.PowderBlue
        Me.ComboBox_FileType.BorderSize = 1
        Me.ComboBox_FileType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_FileType.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_FileType.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_FileType.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_FileType.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_FileType.DropDownHeight = 318
        Me.ComboBox_FileType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FileType.DropDownWidth = 80
        Me.ComboBox_FileType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_FileType.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_FileType.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_FileType.IntegralHeight = False
        Me.ComboBox_FileType.Location = New System.Drawing.Point(215, 35)
        Me.ComboBox_FileType.Name = "ComboBox_FileType"
        Me.ComboBox_FileType.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_FileType.Size = New System.Drawing.Size(73, 21)
        Me.ComboBox_FileType.TabIndex = 95
        Me.ComboBox_FileType.TextPosition = 4
        '
        'txt_SizeY
        '
        Me.txt_SizeY.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt_SizeY.ArrowsIncrement = 1
        Me.txt_SizeY.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_SizeY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_SizeY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_SizeY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SizeY.ForeColor = System.Drawing.Color.Black
        Me.txt_SizeY.Increment = 0.2
        Me.txt_SizeY.Location = New System.Drawing.Point(12, 120)
        Me.txt_SizeY.MaxValue = 50
        Me.txt_SizeY.MinValue = 1
        Me.txt_SizeY.Multiline = True
        Me.txt_SizeY.Name = "txt_SizeY"
        Me.txt_SizeY.NumericValue = 40
        Me.txt_SizeY.NumericValueInteger = 40
        Me.txt_SizeY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_SizeY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_SizeY.RoundingStep = 0
        Me.txt_SizeY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_SizeY.Size = New System.Drawing.Size(36, 16)
        Me.txt_SizeY.SuppressZeros = True
        Me.txt_SizeY.TabIndex = 100
        Me.txt_SizeY.Text = "40"
        Me.txt_SizeY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_StartX
        '
        Me.txt_StartX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txt_StartX.ArrowsIncrement = 1
        Me.txt_StartX.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_StartX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_StartX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_StartX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StartX.ForeColor = System.Drawing.Color.Black
        Me.txt_StartX.Increment = 1
        Me.txt_StartX.Location = New System.Drawing.Point(102, 274)
        Me.txt_StartX.MaxValue = 1000
        Me.txt_StartX.MinValue = 0
        Me.txt_StartX.Multiline = True
        Me.txt_StartX.Name = "txt_StartX"
        Me.txt_StartX.NumericValue = 0
        Me.txt_StartX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_StartX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_StartX.RoundingStep = 0
        Me.txt_StartX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_StartX.Size = New System.Drawing.Size(36, 16)
        Me.txt_StartX.TabIndex = 98
        Me.txt_StartX.Text = "0"
        Me.txt_StartX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_EndX
        '
        Me.txt_EndX.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_EndX.ArrowsIncrement = 1
        Me.txt_EndX.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_EndX.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_EndX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_EndX.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_EndX.ForeColor = System.Drawing.Color.Black
        Me.txt_EndX.Increment = 1
        Me.txt_EndX.Location = New System.Drawing.Point(286, 274)
        Me.txt_EndX.MaxValue = 1000
        Me.txt_EndX.MinValue = 0
        Me.txt_EndX.Multiline = True
        Me.txt_EndX.Name = "txt_EndX"
        Me.txt_EndX.NumericValue = 1000
        Me.txt_EndX.NumericValueInteger = 1000
        Me.txt_EndX.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_EndX.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_EndX.RoundingStep = 0
        Me.txt_EndX.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_EndX.Size = New System.Drawing.Size(36, 16)
        Me.txt_EndX.TabIndex = 94
        Me.txt_EndX.Text = "1000"
        Me.txt_EndX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt_StartY
        '
        Me.txt_StartY.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt_StartY.ArrowsIncrement = 1
        Me.txt_StartY.BackColor = System.Drawing.Color.FloralWhite
        Me.txt_StartY.BackColor_Over = System.Drawing.Color.Moccasin
        Me.txt_StartY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_StartY.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_StartY.ForeColor = System.Drawing.Color.Black
        Me.txt_StartY.Increment = 0.2
        Me.txt_StartY.Location = New System.Drawing.Point(12, 178)
        Me.txt_StartY.MaxValue = 100
        Me.txt_StartY.MinValue = 0
        Me.txt_StartY.Multiline = True
        Me.txt_StartY.Name = "txt_StartY"
        Me.txt_StartY.NumericValue = 30
        Me.txt_StartY.NumericValueInteger = 30
        Me.txt_StartY.RectangleColor = System.Drawing.Color.PowderBlue
        Me.txt_StartY.RectangleStyle = System.Windows.Forms.ButtonBorderStyle.Dashed
        Me.txt_StartY.RoundingStep = 0
        Me.txt_StartY.ShadowColor = System.Drawing.Color.LightGray
        Me.txt_StartY.Size = New System.Drawing.Size(36, 16)
        Me.txt_StartY.SuppressZeros = True
        Me.txt_StartY.TabIndex = 96
        Me.txt_StartY.Text = "30"
        Me.txt_StartY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ComboBox_VideoInputDevice
        '
        Me.ComboBox_VideoInputDevice.ArrowButtonColor = System.Drawing.Color.Transparent
        Me.ComboBox_VideoInputDevice.ArrowColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BackColor = System.Drawing.Color.FloralWhite
        Me.ComboBox_VideoInputDevice.BackColor_Focused = System.Drawing.Color.FloralWhite
        Me.ComboBox_VideoInputDevice.BackColor_Over = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.BorderColor = System.Drawing.Color.DarkGray
        Me.ComboBox_VideoInputDevice.BorderSize = 1
        Me.ComboBox_VideoInputDevice.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox_VideoInputDevice.DropDown_BackColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_BackSelected = System.Drawing.Color.Moccasin
        Me.ComboBox_VideoInputDevice.DropDown_BorderColor = System.Drawing.Color.Cornsilk
        Me.ComboBox_VideoInputDevice.DropDown_ForeColor = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDown_ForeSelected = System.Drawing.SystemColors.WindowText
        Me.ComboBox_VideoInputDevice.DropDownHeight = 318
        Me.ComboBox_VideoInputDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VideoInputDevice.DropDownWidth = 280
        Me.ComboBox_VideoInputDevice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox_VideoInputDevice.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_VideoInputDevice.ForeColor = System.Drawing.Color.Black
        Me.ComboBox_VideoInputDevice.IntegralHeight = False
        Me.ComboBox_VideoInputDevice.Items.AddRange(New Object() {"Auto"})
        Me.ComboBox_VideoInputDevice.Location = New System.Drawing.Point(12, 21)
        Me.ComboBox_VideoInputDevice.Name = "ComboBox_VideoInputDevice"
        Me.ComboBox_VideoInputDevice.ShadowColor = System.Drawing.Color.LightGray
        Me.ComboBox_VideoInputDevice.Size = New System.Drawing.Size(278, 22)
        Me.ComboBox_VideoInputDevice.TabIndex = 32
        Me.ComboBox_VideoInputDevice.TextPosition = 4
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(651, 561)
        Me.Controls.Add(Me.GroupBox_SyncAndIntegration)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.GroupBox_SaveImage)
        Me.Controls.Add(Me.GroupBox_Input)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox_VideoInDevice)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.PBox_Spectrum)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(640, 600)
        Me.Name = "Form_Main"
        Me.Opacity = 0
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Theremino Spectrometer"
        CType(Me.PBox_Camera, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_VideoInDevice.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox_Input.ResumeLayout(False)
        Me.GroupBox_Input.PerformLayout()
        Me.GroupBox_SaveImage.ResumeLayout(False)
        Me.GroupBox_SaveImage.PerformLayout()
        CType(Me.PBox_Spectrum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox_SyncAndIntegration.ResumeLayout(False)
        Me.GroupBox_SyncAndIntegration.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PBox_Camera As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label_FramesPerSec As System.Windows.Forms.Label
    Friend WithEvents ComboBox_VideoInputDevice As MyComboBox
    Friend WithEvents GroupBox_VideoInDevice As System.Windows.Forms.GroupBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Menu_File As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Timer_1Hz As System.Windows.Forms.Timer
    Friend WithEvents Label_Resolution As System.Windows.Forms.Label
    Friend WithEvents Menu_Tools As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_VideoinControls As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tool_VideoControls As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_File_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox_Input As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_FileType As MyComboBox
    Friend WithEvents LabelDot As System.Windows.Forms.Label
    Friend WithEvents chk_Flip As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Path As System.Windows.Forms.Label
    Friend WithEvents Label_Name As System.Windows.Forms.Label
    Friend WithEvents txt_FilePath As MyTextBox
    Friend WithEvents txt_JpegQuality As MyTextBox
    Friend WithEvents Label_JpegQuality As System.Windows.Forms.Label
    Friend WithEvents GroupBox_SaveImage As System.Windows.Forms.GroupBox
    Friend WithEvents Label_StartX As System.Windows.Forms.Label
    Friend WithEvents txt_StartX As MyTextBox
    Friend WithEvents Label_StartY As System.Windows.Forms.Label
    Friend WithEvents txt_StartY As MyTextBox
    Friend WithEvents Label_EndX As System.Windows.Forms.Label
    Friend WithEvents txt_EndX As MyTextBox
    Friend WithEvents PBox_Spectrum As System.Windows.Forms.PictureBox
    Friend WithEvents Label_SizeY As System.Windows.Forms.Label
    Friend WithEvents txt_SizeY As MyTextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents txt_RisingSpeed As MyTextBox
    Friend WithEvents Label_RisingSpeed As System.Windows.Forms.Label
    Friend WithEvents btn_TrimScale As MyButton
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents txt_Filter As MyTextBox
    Friend WithEvents Label_Filter As System.Windows.Forms.Label
    Friend WithEvents Label_Millisec As System.Windows.Forms.Label
    Friend WithEvents Menu_Language As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ENG As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ITA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_FRA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_ESP As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_DEU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_JPN As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_ProgramHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_Construction As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Help_Spectrums As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Menu_Help_OpenProgramFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_About As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tools_SaveSpectrum As System.Windows.Forms.ToolStripButton
    Friend WithEvents txt_FileName As MyTextBox
    Friend WithEvents btn_Peaks As MyButton
    Friend WithEvents btn_Dips As MyButton
    Friend WithEvents btn_Colors As MyButton
    Friend WithEvents Menu_Help_Technology As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tools_SaveCamera As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tools_SaveTotal As System.Windows.Forms.ToolStripButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label_MaxPeak As System.Windows.Forms.Label
    Friend WithEvents btn_Reference As MyButton
    Friend WithEvents Menu_Tools_TrimPoints As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_Trim1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_Trim2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_TrimSelect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_POR As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Language_CHI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Tools_SaveDataFile As System.Windows.Forms.ToolStripButton
    Friend WithEvents Menu_Tools_Separator As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_SeparatorTab As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_SeparatorSemicolon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Menu_Tools_SeparatorComma As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tools_Run As System.Windows.Forms.ToolStripButton
    Friend WithEvents txt_SlotWriteFile As Theremino_Spectrometer.MyTextBox
    Friend WithEvents Label_SlotWriteFile As System.Windows.Forms.Label
    Friend WithEvents Label_SlotRun As System.Windows.Forms.Label
    Friend WithEvents txt_SlotRun As Theremino_Spectrometer.MyTextBox
    Friend WithEvents Label_SlotStop As System.Windows.Forms.Label
    Friend WithEvents txt_SlotStop As Theremino_Spectrometer.MyTextBox
    Friend WithEvents txt_FallingSpeed As Theremino_Spectrometer.MyTextBox
    Friend WithEvents Label_FallingSpeed As System.Windows.Forms.Label
    Friend WithEvents btn_ResetSpectrumData As Theremino_Spectrometer.MyButton
    Friend WithEvents GroupBox_SyncAndIntegration As System.Windows.Forms.GroupBox

End Class
