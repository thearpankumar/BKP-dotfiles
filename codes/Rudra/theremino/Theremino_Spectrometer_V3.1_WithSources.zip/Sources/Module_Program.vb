﻿Public Module Program

    Friend Form_VideoInControls_VisibleAtStart As Boolean = True
    Friend EventsAreEnabled As Boolean = False

End Module
